var searchData=
[
  ['calculate_5fdiscriminant_0',['calculate_discriminant',['../function_8cpp.html#a87c7f5df95e467363052fd3f861e9464',1,'calculate_discriminant(const double a, const double b, const double c):&#160;function.cpp'],['../function_8h.html#a63d2947cac39d706141ba03ea798b2b4',1,'calculate_discriminant(double a, double b, double c):&#160;function.cpp']]],
  ['compare_1',['compare',['../function_8cpp.html#a3c3daebb17d771a4b3a24f33124a50c1',1,'compare(const double n1, const double n2):&#160;function.cpp'],['../function_8h.html#a25f7c61a188b499e0f78cfab27111a70',1,'compare(double n1, double n2):&#160;function.cpp']]]
];
