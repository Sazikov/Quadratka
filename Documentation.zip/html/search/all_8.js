var searchData=
[
  ['square_5fsolver_0',['square_solver',['../function_8cpp.html#afb5c03302234155b71d40926de73959e',1,'square_solver(const double a, const double b, const double c, double *x1, double *x2):&#160;function.cpp'],['../function_8h.html#a44a8b8803ff62f5f101c6dfba6107961',1,'square_solver(double a, double b, double c, double *x1, double *x2):&#160;function.cpp']]]
];
