var searchData=
[
  ['zero_5froots_0',['ZERO_ROOTS',['../function_8h.html#ac6a66a418b6646df5aa3c82d9fb39d3ca52da2ea29bc7f0697300ec26acb69715',1,'function.h']]]
];
