var searchData=
[
  ['one_5froot_0',['ONE_ROOT',['../function_8h.html#ac6a66a418b6646df5aa3c82d9fb39d3ca6700c0f6efd23571cb22aefd2510b1cf',1,'function.h']]],
  ['output_1',['output',['../function_8h.html#a461ce10afb30bdae8f3ff9a84343b5f4',1,'output(const int num_roots, double x1, double x2):&#160;inoutput.cpp'],['../inoutput_8cpp.html#a461ce10afb30bdae8f3ff9a84343b5f4',1,'output(const int num_roots, double x1, double x2):&#160;inoutput.cpp']]]
];
