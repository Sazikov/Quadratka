var searchData=
[
  ['two_5froots_0',['TWO_ROOTS',['../function_8h.html#ac6a66a418b6646df5aa3c82d9fb39d3ca876622d3c0b008da13a3685c64714e81',1,'function.h']]]
];
