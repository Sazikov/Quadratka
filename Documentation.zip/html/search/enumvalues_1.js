var searchData=
[
  ['inf_5froots_0',['INF_ROOTS',['../function_8h.html#ac6a66a418b6646df5aa3c82d9fb39d3ca5a79e9e49077da58fe5d46a98f0b5e36',1,'function.h']]]
];
