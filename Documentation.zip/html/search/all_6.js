var searchData=
[
  ['print_5fequation_0',['print_equation',['../function_8h.html#a6b139e722cc950c8804ccf2dac0f532c',1,'function.h']]]
];
