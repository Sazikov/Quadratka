var searchData=
[
  ['one_5froot_0',['ONE_ROOT',['../function_8h.html#ac6a66a418b6646df5aa3c82d9fb39d3ca6700c0f6efd23571cb22aefd2510b1cf',1,'function.h']]]
];
