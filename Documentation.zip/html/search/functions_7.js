var searchData=
[
  ['testing_5fsquare_5fsolver_0',['Testing_square_solver',['../function_8h.html#ada06866e7ff4701284ea2bb7e2c39fa6',1,'Testing_square_solver(const double a, const double b, const double c, const int num_roots, const double x1_ans, const double x2_ans, int *test_number):&#160;unit_test.cpp'],['../unit__test_8cpp.html#ada06866e7ff4701284ea2bb7e2c39fa6',1,'Testing_square_solver(const double a, const double b, const double c, const int num_roots, const double x1_ans, const double x2_ans, int *test_number):&#160;unit_test.cpp']]]
];
