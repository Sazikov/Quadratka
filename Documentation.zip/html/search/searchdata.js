var indexSectionsWithContent =
{
  0: "cfilmoprstuwz",
  1: "fimu",
  2: "cilmopstu",
  3: "cr",
  4: "ciotwz",
  5: "t"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "enums",
  4: "enumvalues",
  5: "defines"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Файлы",
  2: "Функции",
  3: "Перечисления",
  4: "Элементы перечислений",
  5: "Макросы"
};

