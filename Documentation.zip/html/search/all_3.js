var searchData=
[
  ['linear_5fsolver_0',['linear_solver',['../function_8cpp.html#a20bf6f80f896c639d67af6f19c0276cd',1,'linear_solver(const double k, const double b, double *x1):&#160;function.cpp'],['../function_8h.html#a7548205293a2807b9fa17ba16f8d490a',1,'linear_solver(double k, double b, double *x):&#160;function.cpp']]]
];
