var searchData=
[
  ['roots_0',['roots',['../function_8h.html#ac6a66a418b6646df5aa3c82d9fb39d3c',1,'function.h']]]
];
